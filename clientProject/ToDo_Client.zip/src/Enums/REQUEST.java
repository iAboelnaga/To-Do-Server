/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Enums;

/**
 *
 * @author Aboelnaga
 */
public class REQUEST {
    
    public static final String LOGIN = "LOGIN";

    public static final String POST = "POST";

    public static final String GET = "GET";

    public static final String PUT = "PUT";
    public static final String LOGOUT = "LOGOUT";

    public static final String DELETE = "DELETE";
    //public static final String NOTIFICATION = "notification";
    //public static final String TASK = "task";
    //public static final String TODO = "todo";
    //public static final String SHAREDTODO = "sharedtodo";
    //public static final String NEWCOLLABORATOR = "colltodo";
    public static final String END = "-1";
    //public static final String FRIEND_OFFLINE = "OFFLINE";
    //public static final String FRIEND_ONLINE = "ONLINE";
    //public static final String ACCEPT_FRIEND="friend";
}
