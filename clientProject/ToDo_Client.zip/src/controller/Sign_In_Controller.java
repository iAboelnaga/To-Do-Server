/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Entity.User;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.json.JSONException;
import org.json.JSONObject;
import Helper.Validate;
import server_request.RequestHandler;
import Helper.RequestParam;
import Enums.RESPOND_CODE;
import Enums.MESSAGES;
import javafx.event.ActionEvent;
import javafx.event.Event;
import org.apache.derby.iapi.store.raw.log.LogInstant;


/**
 * FXML Controller class
 *
 * @author tamimy
 */
public class Sign_In_Controller implements Initializable {
    
    @FXML
    private TextField userNameField;

    @FXML
    private PasswordField userPassword;

    @FXML
    private Button login;

    @FXML
    private Label signUpLabel;
    
    private RequestHandler server;
    private String[] params = {RequestParam.LOGIN};
    public static int UserId;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        signUpLabel.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                try {
                    
                    Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                    Scene oldScene = ((Node)event.getSource()).getScene();
                    Parent root = FXMLLoader.load(getClass().getResource("../fxml/sign_up.fxml"));
                    Scene scene = new Scene(root,oldScene.getWidth(),oldScene.getHeight());
                    scene.getStylesheets().add(getClass().getResource("../fxml/style_sheet.css").toExternalForm());
                    stage.setScene(scene);
                    stage.show();
                    
                } catch (IOException ex) {
                    Logger.getLogger(SignupController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }   
    @FXML
    protected void login (ActionEvent event) throws JSONException
    {
       signIn();
       System.out.println("SignIn");
    }
    private void signIn() throws JSONException {
        login.setDisable(true);
        //get userName and password from input field
        String email = userNameField.getText().trim();
        String password = userPassword.getText().trim();

        //check and validate input, if empty password or user name
        boolean isInputNotEmpty = Validate.checkPasswordAndEmail(email, password);

        //if valid input, then make server request
        if (isInputNotEmpty) {
            User user = new User(email, password);
            JSONObject userJson = user.getUserAsJson();

            //TODO:server request in the background, to not freez UI thread
            /* Issue , when making more than one signIn, UI freez 
                even if user input (userName , password) are correct
             */
            try {
                server = new RequestHandler();
                
                JSONObject response = server.post(params, userJson);
                int code = 0;
                //get respond code (SUCCESS , FAILD)after server request
                if (response != null) {
                    code = response.getInt("Code");
                }
                switch (code) {
                    case RESPOND_CODE.SUCCESS:
                        UserId = response.getInt("id");
                        System.out.println("Gooooo");
                        //goToHomeScreen();
                        break;
                    case RESPOND_CODE.FAILD:
                        showFaildAccessMessage();
                        break;
                    
                    case RESPOND_CODE.IS_LOGIN:
                        showIsLoginMessage();
                        break;
                    default:
                        login.setDisable(false);
                }
            } catch (IOException ex) {
                //AlertDialog.showInfoDialog("Connection Down", "Connection Issue", "Please try again");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Connection Down");
                alert.showAndWait();
                login.setDisable(false);
                
            }
        } else {
            //show alert if userName or password is empty
            //AlertDialog.showInfoDialog("Empty User Name or Password", "Invalid Input", "Please try again");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Connection Down");
            alert.showAndWait();
            login.setDisable(false);
        }

        //TODO: send data to server for authontication
    }
    private void showIsLoginMessage() {
        login.setDisable(false);
        userPassword.setText("This User Is Already Loggin");
    }
    private void showFaildAccessMessage() {
        login.setDisable(false);
        // show wrong access message when wrong password or username got entered from user
        userPassword.setText(MESSAGES.WRONG_ACCESS);
    }
    
}
