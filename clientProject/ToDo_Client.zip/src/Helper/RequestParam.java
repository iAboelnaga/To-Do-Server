/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Helper;

/**
 *
 * @author Aboelnaga
 */
public class RequestParam {
    
    public static final String POST= "POST";
    public static final String GET = "GET";
    public static final String DELETE = "DELETE";
    public static final String PUT= "PUT";
    public static final String LOGIN = "LOGIN";
    public static final String REGISTER ="REGISTER";
}
