/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package todo_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.derby.jdbc.ClientDriver;
import todolistproject.User;

/**
 *
 * @author mahmoud mohamed
 */
public class DataBaseHandler {

    private Connection connection;
    private Statement statement;
    static DataBaseHandler access = new DataBaseHandler();
    private ResultSet result;

    private DataBaseHandler() {
        //open database connection
        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/ToDo_Project", "root", "root");
            DriverManager.registerDriver(new ClientDriver());
            statement = connection.createStatement();
            System.out.println("connect to database successfully");
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("open connection failed , please try again ");
        }
    }

    // query insert data on USERS table
    public String insertIntoUsers(User user) {
        try {
            PreparedStatement pst = connection.prepareStatement("INSERT INTO USERS (USER_NAME,EMAIL,PASSWORD) VALUES (?,?,?)");
            pst.setString(1, user.getUserName());
            pst.setString(2,user.getEmail());
            pst.setString(3, user.getPassword());
            pst.executeUpdate();
            return "inserted successfully";
        } catch (SQLException ex) {
            ex.printStackTrace();
            return "can`t insert this row , ensure the data inserted is correct ";
        }
    }

    // query select Email and password from USERS table
    //check select email and password when email found and handle passowrd by code
    public User selectEmail(String email , String pass) {
        User user =new User();
        ResultSet result;
        try {
            PreparedStatement pst = connection.prepareStatement("SELECT * FROM USERS WHERE EMAIL = ?");
            pst.setString(1, email);
            result = pst.executeQuery();
            if (result.next()) {
            do {
                //System.out.println("email is " + result.getString(3) + " password is " + result.getString(4) + " id = "+result.getString(1) +" username "+result.getString(2));
                //handle if passowrd correct or not      
                if (result.getString(4).equals(pass)) {
                    System.out.println("logged in successfully ");
                    user = new User();
                    user.setId(result.getInt(1));
                    user.setUserName(result.getString(2));
                    user.setEmail(result.getString(3));
                    user.setPassword(result.getString(4));
                } else {
                    System.out.println("password incorrect ");
                }
            } while (result.next());
        } else {
            System.out.println("Email not found , please enter correct email");
        }
        } catch (SQLException ex) {
            ex.printStackTrace();
            result = null;
        }
        return user;
    }

    //query select projects that user owned 
    public ResultSet selectOwnedLists(int id) {
        try {
            PreparedStatement pst = connection.prepareStatement("SELECT * FROM LISTS WHERE OWNER_ID = ?");
            pst.setInt(1, id);
            result = pst.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
            result = null;
        }
        return result;
    }

    //query select projects that user work
    public ResultSet selectLists(int id) {
        try {
            PreparedStatement pst = connection.prepareStatement("SELECT * FROM USERS_WORK_LIST , LISTS  WHERE USER_ID = ? AND USERS_WORK_LIST.LIST_ID = LISTS.LIST_ID");
            pst.setInt(1, id);
            result = pst.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
            result = null;
        }
        return result;
    }

    //save request team mate
    //query insert request to Team_Mate table
    public String insertRequestTeamMate(int userID, int teamMateID) {
        try {
            PreparedStatement pst = connection.prepareStatement("INSERT INTO USER_HAS_TEAMMATE (TEAMMATE_ID,USER_ID,TEAMMATE_STATUS) VALUES (?,?,?)");
            pst.setInt(1, teamMateID);
            pst.setInt(2, userID);
            pst.setString(3, "wait");
            pst.executeUpdate();
            System.out.println("inserted correctly");
            return "insert request successfully";

        } catch (SQLException ex) {
            if (ex instanceof SQLIntegrityConstraintViolationException) {
                return "this request sent before";
            } else {
                ex.printStackTrace();
                return "can`t insert this row , ensure the data inserted is correct ";
            }
        }

    }
    //check if request sent before or not

    public ResultSet checkRequestTeamMate(int userID, int teamMateID) {
        try {
            PreparedStatement pst = connection.prepareStatement("SELECT USER_ID FROM USER_HAS_TEAMMATE  WHERE USER_ID = ? AND TEAMMATE_ID =?");
            pst.setInt(1, teamMateID);
            pst.setInt(2, userID);
            result = pst.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
            result = null;
        }
        return result;
    }
    //select all requests team mates 
    public ResultSet selectAllRequestsTeamMate(int userID) {
        try {
            String state = "wait";
            PreparedStatement pst = connection.prepareStatement("SELECT USER_NAME FROM USERS , USER_HAS_TEAMMATE  WHERE USER_HAS_TEAMMATE.TEAMMATE_ID =? AND USERS.USER_ID = USER_HAS_TEAMMATE.USER_ID AND TEAMMATE_STATUS = ? ");
            pst.setInt(1, userID);
            pst.setString(2, state);
            result = pst.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
            result = null;
        }
        return result;
    }
    //change state of team Mate request 
    public String changeRequestTeamMateState(int userID,int teamMate, String state) {
        String response;
        try {
            if (state.equals("accept")) {
                PreparedStatement pst = connection.prepareStatement("UPDATE USER_HAS_TEAMMATE SET TEAMMATE_STATUS = ?  WHERE USER_ID = ? AND TEAMMATE_ID =?");
                pst.setInt(3, teamMate);
                pst.setInt(2, userID);
                pst.setString(1, state);
                pst.executeUpdate();
                response = "request accepted ";
            } else {
                PreparedStatement pst = connection.prepareStatement("DELETE FROM USER_HAS_TEAMMATE   WHERE USER_ID = ? AND TEAMMATE_ID =?");
                pst.setInt(1, userID);
                pst.setInt(2, teamMate);
                pst.executeUpdate();
                response = "request rejected ";
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            response = " can`t change state error on database";
        }
        return response;
    }
    //selecct all requests assign task 
     public ResultSet selectAllRequestsAssignTask(int userID ) {
        try {
            PreparedStatement pst = connection.prepareStatement("SELECT USER_NAME , TASK_DESC , TITLE FROM USERS , TASK ,TASK_ASSIGN_USER , LISTS  WHERE TASK.TASK_ID = TASK_ASSIGN_USER.TASK_ID AND LISTS.LIST_ID = TASK.L_ID AND TASK_ASSIGN_USER.USER_ID = ?  AND USERS.USER_ID = LISTS.OWNER_ID");
            pst.setInt(1, userID);
            result = pst.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
            result = null;
        }
        return result;
    }
   //change state of assign task
     public String changeRequestAssignTaskstate(int userID ,String state)
     {
      String response;
        try {
            if (state.equals("accept")) {
                PreparedStatement pst = connection.prepareStatement("UPDATE TASK_ASSIGN_USER SET TASK_STATUS = ?  WHERE USER_ID = ? ");
                pst.setString(1, state);
                pst.setInt(2, userID);
                pst.executeUpdate();
                response = "request accepted ";
            } else {
                PreparedStatement pst = connection.prepareStatement("DELETE FROM TASK_ASSIGN_USER   WHERE USER_ID = ?");
                pst.setString(1, state);
                pst.setInt(2, userID);
                pst.executeUpdate();
                response = "request rejected ";
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            response = " can`t change state error on database";
        }
        return response;
     }
   //query select task  
     public ResultSet selectList(int listId)
    {
        ResultSet rs = null;       
        try {
            PreparedStatement pst= connection.prepareStatement("select * from LISTS WHERE LIST_ID = ?");
            pst.setInt(1, listId);
            rs = pst.executeQuery() ;
            System.out.println("select successfuly");
        } catch (SQLException ex) {
           ex.printStackTrace();
        }

        return rs;
    }
        //ONLY USED WHEN OWNER SELECT LIST FROM OWNED LIST 

     public void updateList(int listId , String title,String assignDate,String deadlineDate)
    {
        try {
            PreparedStatement pst= connection.prepareStatement("UPDATE LISTS SET  TITLE = ?,ASSIGNDATE = ?,DEADLINEDATE = ? WHERE LIST_ID = ?");
            pst.setString(1,title);
            pst.setString(2,assignDate);
            pst.setString(3,deadlineDate);
            pst.setInt(4,listId);
            pst.executeUpdate(); 
            System.out.println("update List successfuly");
        } catch (SQLException ex) {
           ex.printStackTrace();
        }

    }
         //ONLY USED WHEN OWNER SELECT LIST FROM OWNED LIST 

       public void DeleteList(int listId)
    {
        try {
            PreparedStatement pst = 
                    connection.prepareStatement("DELETE FROM LISTS " +
            "WHERE LIST_ID = ?");
            pst.setInt(1, listId);
            pst.executeUpdate();
            System.out.println("Delete From lists Table");
          
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }
    public ResultSet selectAllTasksInList(int listId)
    {
        ResultSet rs = null;       
        try {
            PreparedStatement pst= connection.prepareStatement("select * from TASK WHERE L_ID = ?");
           
            pst.setInt(1, listId);
            rs = pst.executeQuery() ;
            System.out.println("select successfuly");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return rs;
    }
     public ResultSet selectMyTasksInList(int listId,int userId)
    {
        ResultSet rs = null;       
        try {
             PreparedStatement pst= connection.prepareStatement("select * from TASK,TASK_ASSIGN_USER WHERE L_ID = ? AND USER_ID = ? AND"
                    + " TASK.TASK_ID=TASK_ASSIGN_USER.TASK_ID");
            pst.setInt(1, listId);
            pst.setInt(2, userId);
            rs = pst.executeQuery() ;
            System.out.println("select successfuly");
        } catch (SQLException ex) {
          ex.printStackTrace();
        }

        return rs;
    }
   
    public void ownerInsertTask(String taskDesc,String bg_color,String taskStatus,int listId)
    {
        try {
            PreparedStatement pst= connection.prepareStatement("INSERT INTO TASK (TASK_DESC,BG_COLOR,TASK_STATUS, L_ID)" +
             "VALUES ( ?, ?, ?, ?)");
            pst.setString(1,taskDesc);
            pst.setString(2,bg_color);
            pst.setString(3,taskStatus);
            pst.setInt(4,listId);
            pst.executeUpdate();
            System.out.println("add Task successfuly");
            /*if(uerId>0)
            {
                ownerAssignTask(taskId,uerId,taskStatus);
            }*/
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }
    public void ownerUpdateTask(int taskId ,String taskDesc,String bg_color,String taskStatus)
    {
        try {
            PreparedStatement pst= connection.prepareStatement("UPDATE TASK SET TASK_DESC = ?,BG_COLOR = ?,TASK_STATUS = ? WHERE TASK_ID = ? ");
            pst.setString(1,taskDesc);
            pst.setString(2,bg_color);
            pst.setString(3,taskStatus);
            pst.setInt(4, taskId);
            pst.executeUpdate();
            System.out.println("Update Task successfuly");
           
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void ownerAssignTask(int taskId ,int uerId,String status)
    {
        try {
            PreparedStatement pst= connection.prepareStatement("INSERT INTO TASK_ASSIGN_USER (TASK_ID,USER_ID,TASK_STATUS )" +
             " VALUES (?, ?, ? ) ");
            pst.setInt(1, taskId);
            pst.setInt(2,uerId);
            pst.setString(3,status);
            pst.executeUpdate();
            System.out.println("Assign Task successfuly");
          
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
     public void ownerUpdateUserAssignTask(int taskId ,int uerId,String status)
    {
        try {
            PreparedStatement pst= connection.prepareStatement("UPDATE TASK_ASSIGN_USER SET USER_ID = ?,TASK_STATUS=? WHERE TASK_ID = ? ");
            pst.setInt(1,uerId);
             pst.setString(2,status);
            pst.setInt(3, taskId);
            pst.executeUpdate();
            System.out.println("Update UserAssignTask successfuly");
          
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
     public void normalUserupdateTask(int taskId,String taskStatus)
    {
        try {
            PreparedStatement pst= connection.prepareStatement("UPDATE TASK " +
            "SET TASK_STATUS=? WHERE TASK_ID = ?");
            pst.setString(1,taskStatus);
             pst.setInt(2,taskId);
            pst.executeUpdate();
           // System.out.println(fname);
            System.out.println("update successfuly");
          
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }
      public void AddCommentOnTask(int taskId ,int uerId,String commentDate,String commentText)
    {
        try {
            PreparedStatement pst= connection.prepareStatement("INSERT INTO USER_COMMENT_TASK (TASK_ID,USER_ID,COMMENT_DATE,COMMENT_TEXT )" +
             "VALUES (?, ?, ?,?)");
            pst.setInt(1, taskId);
            pst.setInt(2,uerId);
            pst.setString(3,commentDate);
            pst.setString(4,commentText);

            pst.executeUpdate();
            System.out.println("AddCommentOnTask successfuly");
          
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }
      public void ownerDeleteTask(int TaskId)
    {
        DeleteFromCommentTable(TaskId);
        DeleteFromAssignUserTable(TaskId);
        DeleteFromTaskTable(TaskId);
        
    }
       public void DeleteFromTaskTable(int TaskId)
    {
        try {
            PreparedStatement pst = connection.prepareStatement("DELETE FROM TASK " +
            "WHERE TASK_ID = ?");
            pst.setInt(1, TaskId);
            pst.executeUpdate();
            System.out.println("Delete From Task Table");
          
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
     public void DeleteFromCommentTable(int TaskId)
    {
        try {
            PreparedStatement pst = connection.prepareStatement("DELETE FROM USER_COMMENT_TASK " +
            "WHERE TASK_ID = ?");
            pst.setInt(1, TaskId);
           
            pst.executeUpdate();
            System.out.println("Delete From Comment Table");
          
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }
     public void DeleteFromAssignUserTable(int TaskId)
    {
        try {
            PreparedStatement pst = connection.prepareStatement("DELETE FROM TASK_ASSIGN_USER " +
            "WHERE TASK_ID = ?");
            pst.setInt(1, TaskId);
            pst.executeUpdate();
            System.out.println("Delete From AssignUser Table");
          
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }
    // close connection 
    public void closeConnection() {
        try {
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}
